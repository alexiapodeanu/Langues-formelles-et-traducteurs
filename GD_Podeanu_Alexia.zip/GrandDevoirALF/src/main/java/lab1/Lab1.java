package lab1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

enum Token {
    MISSION("(ENIH|VORI|ELUN|KONN|THEN|OMIR)"),
    UNIT("@[A-Z][0-9][A-Z]"),
    COORD("<[1-9][0-9]*\\|[1-9][0-9]*\\|[1-9][0-9]*>"),
    DIRECTION("(ANESH|ANVAL|SORESH|SORVAL|AN|SOR|ESH|VAL|CI|CO|CU|CA)"),
    MODE("(NANI|NANA|SHAI|ORUN|VELA)"),
    SEPARATOR("!"),
    END("~");

    public final String pattern;

    Token(String pattern)
    {
        this.pattern = pattern;
    }
}

class TokenInstance {
    Token type;
    String value;
    int line;
    int column;

    TokenInstance(Token type, String value, int line, int column) {
        this.type = type;
        this.value = value;
        this.line = line;
        this.column = column;
    }

    public boolean validate() {
        return value.matches(type.pattern);
    }

    @Override
    public String toString() {
        return type + " " + value;
    }
}

public class Lab1 {
    private static final Token[] TOKEN_ORDER = {
            Token.MISSION,
            Token.UNIT,
            Token.COORD,
            Token.DIRECTION,
            Token.MODE,
            Token.SEPARATOR,
            Token.END
    };

    public static List<TokenInstance> tokenize(String input) {
        List<TokenInstance> tokens = new ArrayList<>();
        int index = 0;
        int line = 1;
        int column = 1;

        while (index < input.length()) {
            char current = input.charAt(index);

            if (Character.isWhitespace(current)) {
                if (current == '\n') {
                    line++;
                    column = 1;
                } else {
                    column++;
                }
                index++;
                continue;
            }

            TokenInstance matchedToken = null;
            int matchedLength = 0;

            for (Token token : TOKEN_ORDER) {
                Pattern pattern = Pattern.compile(token.pattern);
                Matcher matcher = pattern.matcher(input);
                matcher.region(index, input.length());

                if (matcher.lookingAt()) {
                    String value = matcher.group();
                    matchedToken = new TokenInstance(token, value, line, column);
                    matchedLength = value.length();
                    break;
                }
            }

            if (matchedToken == null) {
                throw new RuntimeException(
                        "Lexical error at line " + line + ", column " + column +
                                ": unexpected symbol '" + current + "'.");
            }

            tokens.add(matchedToken);
            index += matchedLength;
            column += matchedLength;
        }

        return tokens;
    }

    public static void main(String[] args) throws IOException {
        if (args.length != 1) {
            System.out.println("Usage: java lab1.Lab1 <input-file>");
            return;
        }

        String input = Files.readString(Path.of(args[0]));
        List<TokenInstance> tokens = tokenize(input);

        for (TokenInstance token : tokens) {
            System.out.println(token);
        }
    }
}
